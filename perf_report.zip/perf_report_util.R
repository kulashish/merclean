library(YodleeInsightsConnector)
conn <- YodleeInsightsConnector.connect("askul", "@SkU1Y0dl33")
table.bank  <- "ygm_yod_biuser.jcp_bank_cleanup"
table.card  <- "ygm_yod_biuser.jcp_card_cleanup"
table.panel.bank <- "ygm_stage.bank_panel_stage_tab"
table.panel.card <- "ygm_stage.card_panel_stage_tab"
qtr.12.q3   <- "Q312"
qtr.12.q4   <- "Q412"
qtr.13.q1   <- "Q113"
qtr.13.q2   <- "Q213"
qtr.13.q3   <- "Q313"
qtr.13.q4   <- "Q413"
qtr.14.q1   <- "Q114"
qtr.14.q2   <- "Q214"
type.c      <- "credit"
type.d      <- "debit"
query_amount <- function(table, quarter, type){
  query <- (paste0("select sum(amount) from ", table, " where transaction_base_type='", type, "' and quarter_year='", quarter, "' and currency_id=152 and flag=1"))
  return (YodleeInsightsConnector.query(conn, query)[[1]])
}
query_merchant_users <- function(table, quarter) {
  query <- paste0("select count(distinct unique_mem_id) from ", table, " where quarter_year='", quarter, "' and currency_id=152 and flag=1")
  return (YodleeInsightsConnector.query(conn, query)[[1]])
}
query_merchant_bank_accounts <- function(table, quarter) {
  query <- paste0("select count(distinct unique_bank_account_id) from ", table, " where quarter_year='", quarter, "' and currency_id=152 and flag=1")
  return (YodleeInsightsConnector.query(conn, query)[[1]])
}
query_merchant_card_accounts <- function(table, quarter) {
  query <- paste0("select count(distinct unique_card_account_id) from ", table, " where quarter_year='", quarter, "' and currency_id=152 and flag=1")
  return (YodleeInsightsConnector.query(conn, query)[[1]])
}

query_transacting_users <- function(table, quarter) {
  query <- paste0("select count(distinct unique_mem_id) from ", table, " where ", quarter_condition(quarter), " and currency_id=152")
  return (YodleeInsightsConnector.query(conn, query)[[1]])
}
query_transacting_bank_accounts <- function(table, quarter) {
  query <- paste0("select count(distinct unique_bank_account_id) from ", table, " where ", quarter_condition(quarter), " and currency_id=152")
  return (YodleeInsightsConnector.query(conn, query)[[1]])
}
query_transacting_card_accounts <- function(table, quarter) {
  query <- paste0("select count(distinct unique_card_account_id) from ", table, " where ", quarter_condition(quarter), " and currency_id=152")
  return (YodleeInsightsConnector.query(conn, query)[[1]])
}
quarter_condition <- function(quarter){
  switch(quarter,
         Q312={condition <- "transaction_date >= '2012-08-03' AND transaction_date < '2012-11-03'"},
         Q412={condition <- "transaction_date >= '2012-11-03' AND transaction_date < '2013-02-02'"},
         Q113={condition <- "transaction_date >= '2013-02-02' AND transaction_date < '2013-05-04'"},
         Q213={condition <- "transaction_date >= '2013-05-04' AND transaction_date < '2013-08-03'"},
         Q313={condition <- "transaction_date >= '2013-08-03' AND transaction_date < '2013-11-03'"},
         Q413={condition <- "transaction_date >= '2013-11-03' AND transaction_date < '2014-02-02'"},
         Q114={condition <- "transaction_date >= '2014-02-02' AND transaction_date < '2014-05-03'"},
         {condition <- "transaction_date >= '2014-05-04' AND transaction_date < '2014-08-03'"})
  return (condition)
}
update_flag <- function(table, pattern_list){
  for(pattern in pattern_list){
    update <- paste0("update ", table, " set flag=0 where description ilike '", pattern, "'")
    dbSendUpdate(conn, update)
  }
}